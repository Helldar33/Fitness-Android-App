package com.example.sqliteapp1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class RecordingDataBaseHelper extends SQLiteOpenHelper {

    // public static final String DATABASE_NAME = "FoodFirst_table";
    //public static final String TABLE_NAME = "FoodFirst_table";



    public RecordingDataBaseHelper(@Nullable Context context) {
        super(context, "Record.db", null, 1);
    }

    // this is called the first time a database is accessed. There should be a code to create a new database. Also, I changed sqLiteDatabase on db.
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement = "CREATE TABLE " + Record_Table() + " (" + Column_ID() + " INTEGER PRIMARY KEY AUTOINCREMENT, " + Column_Name() + " TEXT, " + Column_Multiplier() + " INT, " + Column_Calories() + " INT, " + Column_Timestamp() + " INT)";
        // colloms to be used - is after ID INTEGER PRIMARY KEY AUTOINCREMENT, ...

        db.execSQL(createTableStatement);

    }

    private static String Column_ID() {
        return "ID";
    }
    private static String Column_Name() { return "Name"; }
    private static String Column_Multiplier() { return "Multiplier"; }
    private static String Column_Calories() { return "Calories"; }
    private static String Column_Timestamp() { return "Timestamp"; }
    private static String Record_Table() { return "RECORD_TABLE"; }

    // this is called if the database version number changes. It prevents previous users apps from breaking when you changed the database design.
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

    }

    // No need to specify ID of the new recorded table. The ID column is auto incremented

    public boolean addOne(Record record) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(Column_Name(), record.getName());
        cv.put(Column_Multiplier(), record.getMultiplier());
        cv.put(Column_Calories(), record.getCalories());
        cv.put(Column_Timestamp(), record.getTimestamp());



        long insert = db.insert(Record_Table(), null, cv);
        if (insert == -1){
            return false;
        }
        else {
            return true;
        }

    }

    public boolean deleteOne(Record record){
        // 1) find listOfFood in the database. 2) if it is found, delete it and return true value.
        // if it is not found, return false.
        // This is DAO or Data Assess Object style
        SQLiteDatabase db = this.getWritableDatabase(); // 'getWritableDatabase' because I am going to have changes like deleting in the database
        String queryString = "DELETE FROM " + Record_Table() + " WHERE " + Column_ID() + " = " + record.getId();
        Cursor cursor = db.rawQuery(queryString, null);

        if (cursor.moveToFirst()) {
            return true;
        }
        else {
            return false;
        }
    }
    public List<Record> getEveryone() {

        List<Record> returnList = new ArrayList<>();

        String queryString = "SELECT * FROM " + Record_Table();
//todo SELECT * FROM your_table WHERE timestamp > 150000 AND timestamp < 150010
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);

        // cursor.moveToFirst() returns a true if there were items selected

        if (cursor.moveToFirst()) {
            // loop through cursor (result set) and create a new object for each raw. Put them into the return list.
            do {
                int RecordID = cursor.getInt(0);
                String RecordName = cursor.getString( 1);
                int RecordMultiplier = cursor.getInt(2);
                int RecordCalories = cursor.getInt(3);
                long RecordTimestamp = cursor.getInt(4);

                Record newrecordraw = new Record(RecordID, RecordName, RecordMultiplier, RecordCalories, RecordTimestamp);
                returnList.add(newrecordraw);

            } while (cursor.moveToNext());


        }

        else {
            // If no results from my database, then no additing any new object to the list.
        }

        //close cursor and my db
        cursor.close();
        db.close();
        return returnList;
    }

    public long getStartOfDay() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTimeInMillis() / 1000;
    }

    public int getCalories() {
        long startTime = getStartOfDay();
        long endTime = startTime + 24 * 60 * 60;
        String queryString = "SELECT Timestamp, Calories FROM RECORD_TABLE WHERE Timestamp > " + startTime + " AND Timestamp < " + endTime + " ORDER BY Timestamp";

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);

        int totalcalories = 0;

        if (cursor.moveToFirst()) {
            // loop through cursor (result set) and create a new object for each raw. Put them into the return list.
            do {
                int calories = cursor.getInt(1);

                totalcalories += calories;



            } while (cursor.moveToNext());


        }

        else {
            // If no results from my database, then no additing any new object to the list.
        }

        //close cursor and my db
        cursor.close();
        db.close();
        return totalcalories;

    }


}
