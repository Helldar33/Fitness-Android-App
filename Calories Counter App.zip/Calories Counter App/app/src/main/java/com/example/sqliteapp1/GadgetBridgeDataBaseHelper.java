package com.example.sqliteapp1;

import android.content.Context;
import android.content.ContextWrapper;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;

import androidx.annotation.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

class DataBaseContext extends ContextWrapper {

    private static final String DEBUG_CONTEXT = "DataBaseContext";

    @Override
    public SQLiteDatabase openOrCreateDatabase(String name, int mode, SQLiteDatabase.CursorFactory factory, DatabaseErrorHandler errorHandler) {
        return openOrCreateDatabase(name,mode, factory);
    }
    @Override
    public SQLiteDatabase openOrCreateDatabase(String name, int mode, SQLiteDatabase.CursorFactory factory) {
        SQLiteDatabase result = SQLiteDatabase.openOrCreateDatabase(getDatabasePath(name), null);

        return result;
    }

    public DataBaseContext(Context base) {
        super(base);
    }

    @Override
    public File getDatabasePath(String name) {
        File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + "Gadgetbridge.db");
        return file;
    }
}


public class GadgetBridgeDataBaseHelper extends SQLiteOpenHelper {

    // public static final String DATABASE_NAME = "FoodFirst_table";
    //public static final String TABLE_NAME = "FoodFirst_table";



    public GadgetBridgeDataBaseHelper(@Nullable Context context) {
        super(new DataBaseContext(context), "/storage/emulated/0/Gadgetbridge.db", null, 27);
//        super(context, "/storage/emulated/0/Android/data/nodomain.freeyourgadget.gadgetbridge/files/Gadgetbridge", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    }

    // this is called if the database version number changes. It prevents previous users apps from breaking when you changed the database design.
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

    }

    public List<Food> getEveryone() {

        List<Food> returnList = new ArrayList<>();
        // todo Should I change/delete the list?
        // get data from the database

        String queryString = "SELECT * FROM MI_BAND_ACTIVITY_SAMPLE";

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);

        // cursor.moveToFirst() returns a true if there were items selected

        if (cursor.moveToFirst()) {
            // loop through cursor (result set) and create a new object for each raw. Put them into the return list.
            do {
                // Introduce new local variable of the type tha t we expect to come from my database. First is always ID. Due to my design of the table the ID is 0.
                // Use Turnary Operator for booleans data selection.
                int timestamp = cursor.getInt(0);
                int raw_intensity = cursor.getInt(3);
                int steps = cursor.getInt(4);
                int heart_rate = cursor.getInt(6);




            } while (cursor.moveToNext());


        }

        else {
            // If no results from my database, then no additing any new object to the list.
        }

        //close cursor and my db
        cursor.close();
        db.close();
        return returnList;
    }

    public long getStartOfDay() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTimeInMillis() / 1000;
    }

    public int getCalories() {
        long startTime = getStartOfDay();
        long endTime = startTime + 24 * 60 * 60;
        String queryString = "SELECT TIMESTAMP, HEART_RATE FROM MI_BAND_ACTIVITY_SAMPLE WHERE TIMESTAMP > " + startTime + " AND TIMESTAMP < " + endTime + " ORDER BY TIMESTAMP";

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);

        int lastHeartRate = -1;
        long lastTimeStamp = -1;
        double totalCalories = 1893;
//        How many calories I spend without any activities is my BMR


        if (cursor.moveToFirst()) {
            // loop through cursor (result set) and create a new object for each raw. Put them into the return list.
            do {
                long timestamp = cursor.getLong(0);
                int heart_rate = cursor.getInt(1);

                if (heart_rate > 20 && heart_rate < 220){
                    if (lastHeartRate == -1){
                        lastHeartRate = heart_rate;
                        lastTimeStamp = timestamp;
                    }
                    else {
                        long duration = timestamp - lastTimeStamp;
                        int averageHeartRate = (heart_rate + lastHeartRate)/2;
//                        ((-55.0969 + (0.6309 * HR) + (0.1988 * W) + (0.2017 * A))/4.184) * 60 * T
                        double calories = (((-55.0969 + (0.6309 * (float) averageHeartRate) + (0.1988 * 60) + (0.2017 * 18))/4.184) * (float) duration/60);
                        totalCalories += calories > 0 ? calories : 0;
                        lastHeartRate = heart_rate;
                        lastTimeStamp = timestamp;

                    }

                }

            } while (cursor.moveToNext());


        } else {

        }


        cursor.close();
        db.close();


        return (int) totalCalories;
    }



}
