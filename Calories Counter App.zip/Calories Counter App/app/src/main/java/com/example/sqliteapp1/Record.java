package com.example.sqliteapp1;

public class Record {

    private int id;
    private String name;
    private int multiplier;
    private long timestamp;
    private int calories;

    public Record(int id, String name, int multiplier, int calories, long timestamp) {
        this.id = id;
        this.name = name;
        this.multiplier = multiplier;
        this.calories = calories;
        this.timestamp = timestamp;

    }

    public int getId() { return id; }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMultiplier() {
        return multiplier;
    }

    public void setMultiplier(int multiplier) {
        this.multiplier = multiplier;
    }

    public int getCalories() {
        return calories;
    }

    public void setCalories(int calories) {
        this.calories = calories;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return name + " and multiplier: " + multiplier;
    }
}



