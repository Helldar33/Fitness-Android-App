package com.example.sqliteapp1;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts.RequestPermission;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Spinner;


import java.util.List;

public class MainActivity extends AppCompatActivity {

    // references to all button and other controls on the layout
    Button btn_Add, btn_ViewAll;
    EditText et_Multiplier;
    ListView lv_Record;
    Spinner spinner;
    TextView daily_burnt_calories;
    TextView daily_gained_calories;
    TextView daily_difference;



    ArrayAdapter RecordArrayAdapter;
    RecordingDataBaseHelper recordingDataBaseHelper;
    GadgetBridgeDataBaseHelper gadgetBridgeDataBaseHelper;

    private ActivityResultLauncher<String> requestPermissionLauncher = registerForActivityResult( new RequestPermission(), isGranted->{});


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_Add = findViewById(R.id.btnAdd);
        btn_ViewAll = findViewById(R.id.btnViewAll);
        et_Multiplier = findViewById(R.id.Multiplier);
        spinner = findViewById(R.id.spinner1);
        lv_Record = findViewById(R.id.lv_Food_List);
        daily_burnt_calories = findViewById(R.id.Daily_Burnt_Calories);
        daily_gained_calories = findViewById(R.id.Daily_Gained_Calories);
        daily_difference = findViewById(R.id.Daily_Difference);

        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
            requestPermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }

        //ArrayAdapter<Food> adapter = ArrayAdapter.createFromResource(this, R.array.names, android.R.layout.simple_spinner_item);
        //adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

//        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
//
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> adapterView) {
//
//            }
//        });
        loadSpinnerData();

//wdfw

        gadgetBridgeDataBaseHelper = new GadgetBridgeDataBaseHelper( MainActivity.this);
        daily_burnt_calories.setText("Daily calories burnt: " + Integer.toString(gadgetBridgeDataBaseHelper.getCalories()) + " Your goal is: 2500");

        recordingDataBaseHelper = new RecordingDataBaseHelper( MainActivity.this);
        daily_gained_calories.setText("Daily calories gained: " + Integer.toString(recordingDataBaseHelper.getCalories()) + " Your goal is: 2000");

        daily_difference.setText("Daily calories difference: " + Integer.toString(recordingDataBaseHelper.getCalories() - gadgetBridgeDataBaseHelper.getCalories()) + " Your goal is to have: -500");

                RecordArrayAdapter = new ArrayAdapter<Record>(MainActivity.this, android.R.layout.simple_list_item_1, recordingDataBaseHelper.getEveryone());
        lv_Record.setAdapter(RecordArrayAdapter);

        // button listeners for the add and view all buttons
        btn_Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Record record;
                Food selectedfood = (Food) spinner.getSelectedItem();
                int calories;
                try {
                    calories = (int) (Float.parseFloat(et_Multiplier.getText().toString()) * selectedfood.getCalories());
                }
                catch (NumberFormatException e ){
                    Toast.makeText(MainActivity.this, "Invalid Multiplier format!", Toast.LENGTH_SHORT).show();
                    return;
                }



                record = new Record( -1, selectedfood.getName(), Integer.parseInt(et_Multiplier.getText().toString()), calories, System.currentTimeMillis() / 1000);

                RecordingDataBaseHelper recordingDataBaseHelper = new RecordingDataBaseHelper(MainActivity.this );

                boolean success = recordingDataBaseHelper.addOne(record);

                Toast.makeText(MainActivity.this, "Success= " + success, Toast.LENGTH_SHORT).show();
                RecordArrayAdapter = new ArrayAdapter<Record>(MainActivity.this, android.R.layout.simple_list_item_1, recordingDataBaseHelper.getEveryone());
                lv_Record.setAdapter(RecordArrayAdapter);

                daily_burnt_calories.setText("Daily calories burnt: " + Integer.toString(gadgetBridgeDataBaseHelper.getCalories()) + " Your goal is: 2500");
                daily_gained_calories.setText("Daily calories gained: " + Integer.toString(recordingDataBaseHelper.getCalories()) + " Your goal is: 2000");
                daily_difference.setText("Daily calories difference: " + Integer.toString(recordingDataBaseHelper.getCalories() - gadgetBridgeDataBaseHelper.getCalories()) + " Your goal is to have: -500");

            }
        });

        btn_ViewAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RecordingDataBaseHelper recordingDataBaseHelper = new RecordingDataBaseHelper( MainActivity.this);
                List<Record> everyone = recordingDataBaseHelper.getEveryone();

                ArrayAdapter foodArrayAdapter = new ArrayAdapter<Record>(MainActivity.this, android.R.layout.simple_list_item_1, everyone);
                lv_Record.setAdapter(foodArrayAdapter);

                daily_burnt_calories.setText("Daily calories burnt: " + Integer.toString(gadgetBridgeDataBaseHelper.getCalories()) + " Your goal is: 2500");
                daily_gained_calories.setText("Daily calories gained: " + Integer.toString(recordingDataBaseHelper.getCalories()) + " Your goal is: 2000");
                daily_difference.setText("Daily calories difference: " + Integer.toString(recordingDataBaseHelper.getCalories() - gadgetBridgeDataBaseHelper.getCalories()) + " Your goal is to have: -500");

                //Toast.makeText(MainActivity.this, everyone.toString(), Toast.LENGTH_SHORT).show();
            }
        });
        lv_Record.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Record ClickedRecord = (Record) adapterView.getItemAtPosition(i);
                recordingDataBaseHelper.deleteOne(ClickedRecord);
                RecordArrayAdapter = new ArrayAdapter<Record>(MainActivity.this, android.R.layout.simple_list_item_1, recordingDataBaseHelper.getEveryone());
                lv_Record.setAdapter(RecordArrayAdapter);
                Toast.makeText(MainActivity.this, " Deleted " + ClickedRecord.toString(), Toast.LENGTH_SHORT).show();

                daily_burnt_calories.setText("Daily calories burnt: " + Integer.toString(gadgetBridgeDataBaseHelper.getCalories()) + " Your goal is: 2500");
                daily_gained_calories.setText("Daily calories gained: " + Integer.toString(recordingDataBaseHelper.getCalories()) + " Your goal is: 2000");
                daily_difference.setText("Daily calories difference: " + Integer.toString(recordingDataBaseHelper.getCalories() - gadgetBridgeDataBaseHelper.getCalories()) + " Your goal is to have: -500");


            }
        });

    }

    private void loadSpinnerData() {
        FoodCaloriesDataBaseHelper db = new FoodCaloriesDataBaseHelper(getApplicationContext());
        List<Food> food = db.getEveryone();

        // Creating adapter for spinner
        ArrayAdapter<Food> dataAdapter = new ArrayAdapter<Food>(this,android.R.layout.simple_spinner_item, food);
        //todo only name not id or calories

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);
    }

}