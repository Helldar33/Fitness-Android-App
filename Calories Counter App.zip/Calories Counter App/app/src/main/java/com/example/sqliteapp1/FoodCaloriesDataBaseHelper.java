package com.example.sqliteapp1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class FoodCaloriesDataBaseHelper extends SQLiteOpenHelper {

    // public static final String DATABASE_NAME = "FoodFirst_table";
    //public static final String TABLE_NAME = "FoodFirst_table";


    public FoodCaloriesDataBaseHelper(@Nullable Context context) {
        super(context, "FoodCalories.db", null, 1);
    }

    // this is called the first time a database is accessed. There should be a code to create a new database. Also, I changed sqLiteDatabase on db.
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement = "CREATE TABLE " + Food_table() + " (" + Column_ID() + " INTEGER PRIMARY KEY AUTOINCREMENT, " + Column_Name() + " TEXT, " + Column_Calories() + " INT)";
        // colloms to be used - is after ID INTEGER PRIMARY KEY AUTOINCREMENT, ...

        db.execSQL(createTableStatement);
        //this.addOne(new Food(0, "Spaget", 600));
        ArrayList<Food> foodinit = new ArrayList<Food>();
        foodinit.add(new Food(0, "Buckwheat", 280));
        foodinit.add(new Food(1, "Curry", 500));
        foodinit.add(new Food(2, "Fajitas", 600));
        foodinit.add(new Food(3, "Granola", 300));
        foodinit.add(new Food(4, "Spaghetti", 600));
        foodinit.add(new Food(5, "Sirniki", 70));
        foodinit.add(new Food(6, "Sсhi", 600));
        foodinit.add(new Food(7, "Traybakes", 550));
        foodinit.add(new Food(8, "Omelettes", 250));
        foodinit.add(new Food(9, "Pancakes 5 pieces", 250));
        foodinit.add(new Food(10, "Pasta bake", 600));
        foodinit.add(new Food(11, "Pasta bake", 600));
        foodinit.add(new Food(12, "Pasta on the hob", 600));
        foodinit.add(new Food(13, "Pelmeni", 400));
        foodinit.add(new Food(14, "Pirog", 450));
        foodinit.add(new Food(15, "Varenniki", 350));
        foodinit.add(new Food(16, "Vinegrette", 300));


        for (Food food: foodinit) {
            ContentValues cv = new ContentValues();

            cv.put(Column_Name(), food.getName());
            cv.put(Column_Calories(), food.getCalories());


            long insert = db.insert(Food_table(), null, cv);

        }

    }

    private static String Column_ID() {
        return "ID";
    }

    private static String Column_Name() {
        return "Name";
    }

    private static String Column_Calories() { return "Calories"; }

    private static String Food_table() {
        return "FOOD_TABLE";
    }

    // this is called if the database version number changes. It prevents previous users apps from breaking when you changed the database design.
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

    }

    // No need to specify ID of the new recorded table. The ID column is auto incremented



    public boolean addOne(Food food) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(Column_Name(), food.getName());
        cv.put(Column_Calories(), food.getCalories());


        long insert = db.insert(Food_table(), null, cv);
        if (insert == -1) {
            return false;
        } else {
            return true;
        }
    }


    public List<Food> getEveryone() {

        List<Food> returnList = new ArrayList<>();

        String queryString = "SELECT * FROM " + Food_table();

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String name = cursor.getString( 1);
                int calories = cursor.getInt(2);

                Food newfood = new Food(id, name, calories);
                returnList.add(newfood);

            } while (cursor.moveToNext());


        }

        else {

        }

        cursor.close();
        db.close();
        return returnList;
    }
}
